package com.audintel.jpa.joined;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="manager_js")
public class ManagerJS extends EmployeeJS {

	private static final long serialVersionUID = 1L;
	
	private String departmentName;

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
	

}
