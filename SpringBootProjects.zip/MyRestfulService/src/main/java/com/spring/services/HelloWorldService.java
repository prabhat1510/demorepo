package com.spring.services;

import org.springframework.stereotype.Service;

@Service
public class HelloWorldService {

	public String welcomeMessage() {
		return "How are you?";
	}
}
