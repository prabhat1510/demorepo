package com.spring.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.EmpDao;
import com.spring.domain.Emp;

@Service
public class EmpServices {
	
	@Autowired
	EmpDao dao;

	public ArrayList<Emp> getAll(){
		return dao.getAll();
	}
	
	public ArrayList<Emp> insertEmp(Emp e){
		return dao.insertEmp(e);
	}

}
