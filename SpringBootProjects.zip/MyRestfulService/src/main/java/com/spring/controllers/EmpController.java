package com.spring.controllers;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.domain.Emp;
import com.spring.services.EmpServices;

@RestController
public class EmpController {

	@Autowired
	EmpServices empService;
	
	@GetMapping(value="/emps", 
			produces= {MediaType.APPLICATION_JSON_VALUE, 
					MediaType.APPLICATION_XML_VALUE})
	public ArrayList<Emp> getAll(){
		return this.empService.getAll();
	}
		
	@PostMapping(value="/emps",
			produces= {MediaType.APPLICATION_JSON_VALUE, 
					MediaType.APPLICATION_XML_VALUE},
			consumes= {MediaType.APPLICATION_JSON_VALUE})
	public ArrayList<Emp> insertEmp(@RequestBody Emp e){
		return empService.insertEmp(e);
	}
}
