package com.lm;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CountryController {
	@RequestMapping(value = "/country")
    public ResponseEntity<Country> getCountry() {
        
		Country c = new Country();
        c.setName("France");
        c.setPopulation(66984000);
        
        HttpHeaders headers = new HttpHeaders();
        headers.add("Responded", "CountryController");
        
        return ResponseEntity.accepted().headers(headers).body(c);
    }
    
    @RequestMapping(value = "/country2")
    @ResponseBody
    public Country getCountry2() {
        
    	Country c = new Country();
        c.setName("France");
        c.setPopulation(66984000);
        
        return c;
    }    
}
