package com.cs.helloworld;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class HelloWorldController {

	
//	@GetMapping("/hello")
//    public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
//        model.addAttribute("name");
//        return "hello";
//    }
	
	@RequestMapping("/")
    ModelAndView index(){
		 ModelAndView mav = new ModelAndView("index");
		 mav.addObject("version", "0.1");
        return mav;
    }


}
