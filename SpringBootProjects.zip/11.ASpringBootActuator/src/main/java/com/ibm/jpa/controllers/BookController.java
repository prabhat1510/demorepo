package com.ibm.jpa.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.jpa.domain.Books;
import com.ibm.jpa.services.BookService;

@RestController
public class BookController {
	
	@Autowired
	BookService service;

	@GetMapping("/books")
	public List<Books> getAllBooks(){
		return this.service.getBooks();
	}
	
	@PostMapping("/books")
	public void addBook(@RequestBody Books book) {
		this.service.addBook(book);
	}
	
	@GetMapping("/books/{id}")
	public Books getById(@PathVariable long id) {
		return this.service.getBookById(id);
	}
	
	@GetMapping("/books/byname/{name}")
	public List<Books> getByName(@PathVariable String name) {
		return this.service.getBookByName(name);
	}
	
	
	@DeleteMapping("/books/{id}")
	public void deleteBook(@PathVariable long id) {
		this.service.deleteBook(id);
	}
	
}
