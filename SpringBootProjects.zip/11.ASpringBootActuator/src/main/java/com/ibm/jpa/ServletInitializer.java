package com.ibm.jpa;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

public class ServletInitializer extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(SpringJpaApplication.class);
	}
	
//	/metrics	To view the application metrics such as memory used, memory free, threads, classes, system uptime etc.
//	/env	To view the list of Environment variables used in the application.
//	/beans	To view the Spring beans and its types, scopes and dependency.
//	/health	To view the application health
//	/info	To view the information about the Spring Boot application.
//	/trace	To view the list of Traces of your Rest endpoints.

//	
//	/auditevents: Exposes audit events information for the current application.
//	/beans: Returns list of all spring beans in the application.
//	/caches: Gives information about the available caches.
//	/health: Provides applications health information.
//	/conditions: Provides list of conditions those were evaluated during auto configurations.
//	/configprops: Returns list of application level properties.
//	/info: Provides information about current application. This info can be configured in a properties file.
//	/loggers: Displays logging configurations. Moreover, this endpoint can be used to modify the configurations.
//	/headdump: Produces a head dump file and returns it.
//	/metrics: Returns various metrics about the application. Includes memory, heap and threads info. However, this endpoint doesn’t return any metrics. While, it only returns list of available metrics, the metrics names can be used in a separate request to fetch the respective details. For instance, /actuator/metrics/jvm.memory.max like this.
//	/scheduledtasks: Returns a list of Scheduled tasks in the application.
//	/httptrace: Returns last 100 http interactions in the form of request and response. Including, the actuator endpoints.
//	/mappings: List of all Http Request Mappings. Also includes the actuator endpoints.
}
