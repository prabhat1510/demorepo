package com.lm;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
	 @RequestMapping("/")
	    public HttpEntity<String> handleRequest (HttpEntity<String> requestEntity) {
	       System.out.println("request body: " + requestEntity.getBody());
	        HttpHeaders headers = requestEntity.getHeaders();
	        System.out.println("request headers " + headers);
	        HttpEntity<String> responseEntity = new HttpEntity<String>("my response body");
	        return responseEntity;
	    }
}
