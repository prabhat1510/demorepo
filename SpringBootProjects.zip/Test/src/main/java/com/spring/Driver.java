package com.spring;

import java.util.Currency;

public class Driver {
	
	public static void main(String[] args) {
		Currency c = Currency.getInstance("INR");
	}

}
