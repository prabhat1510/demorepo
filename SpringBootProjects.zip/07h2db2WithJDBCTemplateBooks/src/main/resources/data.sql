insert into books(id, name, price) values(1,'Siva',200);
insert into books(id, name, price) values(2,'Prasad',500);
insert into books(id, name, price) values(3,'Reddy',999);