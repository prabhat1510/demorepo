package com.example.demo.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Books;

import java.util.List;

public interface BookRepository extends CrudRepository<Books, Long> {

	@Query(
			  value = "SELECT * FROM books WHERE name = ?1", 
			  nativeQuery = true)
    List<Books> findByName(String name);

}
